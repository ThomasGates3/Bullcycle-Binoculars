import { APIGatewayProxyHandler } from 'aws-lambda';
export declare const handler: APIGatewayProxyHandler;
//# sourceMappingURL=handler.d.ts.map